import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class JavaCRUD {

    //VIUSUAL

    private JLabel lblNOMBRE;
    private JLabel lblFECHAENVASADO;
    private JLabel lblMOSTRARPRODUCTO;
    private JLabel lblUNIDADES;
    private JLabel lblPRECIO;
    private JLabel lblDISPONIBLE;
    private JTextField txtNOMBRE;
    private JTextField txtFECHAENVASADO;
    private JTextField txtUNIDADES;
    private JTextField txtPRECIO;
    private JButton btnAÑADIRPRODUCTO;
    private JTable Tabla;
    private JButton btnMOSTRARPRODUCTO;
    private JButton btnELIMINARPRODUCTO;
    private JButton btnACTUALIZARPRODUCTO;
    private JPanel Main;
    private JCheckBox cboxDISPONIBLE;
    private JLabel lblID;
    private JTextField txtId;
    PreparedStatement pst;
    Connection con;


    //CONEXION

    public void Connection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "");
            System.out.println("Conexion completada");
        } catch (Exception e) {
            System.out.println("Error en la conexión");
            System.out.println("El error es " + e.getMessage());
        }
    }//cierra Connection

    //CARGAR PRODUCTOS
    public void cargarProductos(){
        try{
            pst = con.prepareStatement("select * from hipg");
            ResultSet rs = pst.executeQuery();
            Tabla.setModel(DbUtils.resultSetToTableModel(rs));
        }catch(Exception a1){
            System.out.println("El error es "+a1);
        }
    }//cierra cargarProductos


    //MAIN
    public static void main(String[] args) {
        JFrame frame = new JFrame("JavaCRUD");
        frame.setContentPane(new JavaCRUD().Main);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }


    //BOTON AÑADIR PRODUCTO
    public JavaCRUD() {
        Connection();
        btnAÑADIRPRODUCTO.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                String  NOMBRE = txtNOMBRE.getText();
                String FECHA_ENVASADO = txtFECHAENVASADO.getText();
                int UNIDADES = Integer.parseInt(txtUNIDADES.getText());
                float PRECIO = Float.parseFloat(txtPRECIO.getText());
                boolean DISPONIBLE = Boolean.parseBoolean(cboxDISPONIBLE.getText());

                try{
                    pst = con.prepareStatement("insert into hipg(NOMBRE, FECHA_ENVASADO, UNIDADES, PRECIO, DISPONIBLE) values(?,?,?,?,?)");
                    pst.setString(1, NOMBRE);
                    pst.setString(2, FECHA_ENVASADO);
                    pst.setInt(3, UNIDADES);
                    pst.setFloat(4, PRECIO);
                    pst.setBoolean(5, DISPONIBLE);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Producto añadido");
                    cargarProductos();
                } catch (Exception a2) {
                    System.out.println("Error al añadir el producto");
                    throw new RuntimeException(a2);
                }
            }
        });



        //BOTON CARGAR PRODUCTOS
        btnMOSTRARPRODUCTO.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(txtId.getText());
                try {
                    pst = con.prepareStatement("select * from hipg where ID_PRODUCTO = ?");
                    pst.setInt(1, id);
                    JOptionPane.showMessageDialog(null, "Producto mostrado");
                    cargarProductos();
                    ResultSet rs = pst.executeQuery();


                } catch (SQLException ex) {
                    System.out.println("Error al mostrar los productos");
                    throw new RuntimeException(ex);
                }
            }
        });


        //BOTON DE ELIMINAR
        btnELIMINARPRODUCTO.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(txtId.getText());
                try {
                    pst = con.prepareStatement("delete from hipg where ID_PRODUCTO = ?");
                    pst.setInt(1, id);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Producto eliminado");
                    cargarProductos();


                } catch (SQLException ex) {
                    System.out.println("Error al mostrar los productos");
                    throw new RuntimeException(ex);
                }
            }
        });
        btnACTUALIZARPRODUCTO.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(txtId.getText());
                String  NOMBRE = txtNOMBRE.getText();
                String FECHA_ENVASADO = txtFECHAENVASADO.getText();
                int UNIDADES = Integer.parseInt(txtUNIDADES.getText());
                float PRECIO = Float.parseFloat(txtPRECIO.getText());
                boolean DISPONIBLE = Boolean.parseBoolean(cboxDISPONIBLE.getText());

                try{
                    pst = con.prepareStatement("update hipg set NOMBRE = ?, FECHA_ENVASADO = ?, UNIDADES = ?, PRECIO = ?, DISPONIBLE = ? where ID_PRODUCTO = ?");
                    pst.setString(1, NOMBRE);
                    pst.setString(2, FECHA_ENVASADO);
                    pst.setInt(3, UNIDADES);
                    pst.setFloat(4, PRECIO);
                    pst.setBoolean(5, DISPONIBLE);
                    pst.setInt(6, id);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Producto actualizado");
                    cargarProductos();

                } catch (Exception a2) {
                    System.out.println("Error al modificar el producto");
                    throw new RuntimeException(a2);
                }
            }
        });
    }


}//cierra clase JAVACRUD



